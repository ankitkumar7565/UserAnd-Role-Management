"use client"

import { useState } from "react"
import { useCalculatorStore } from "../store/calculatorStore"
import ComponentPalette from "./ComponentPalette"
import CalculatorPreview from "./CalculatorPreview"
import type React from "react" // Added import for React

const CalculatorBuilder: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const { components, addComponent, removeComponent, clearComponents } = useCalculatorStore()

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <div className={`flex flex-col items-center ${isDarkMode ? "dark" : ""}`}>
      <div className="mb-4">
        <button
          onClick={toggleDarkMode}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
        >
          Toggle Dark Mode
        </button>
      </div>
      <div className="flex space-x-8">
        <ComponentPalette />
        <CalculatorPreview />
      </div>
      <button
        onClick={clearComponents}
        className="mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
      >
        Clear Calculator
      </button>
    </div>
  )
}

export default CalculatorBuilder

