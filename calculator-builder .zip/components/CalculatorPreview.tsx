import { useDrop } from "react-dnd"
import { useCalculatorStore } from "../store/calculatorStore"
import type React from "react" // Added import for React

const CalculatorPreview: React.FC = () => {
  const { components, addComponent, removeComponent, calculate } = useCalculatorStore()

  const [, drop] = useDrop(() => ({
    accept: "component",
    drop: (item: { type: string; label: string }) => {
      addComponent(item)
    },
  }))

  return (
    <div ref={drop} className="bg-gray-200 p-4 rounded-lg shadow-md min-h-[300px] min-w-[200px] dark:bg-gray-700">
      <h2 className="text-xl font-semibold mb-4 dark:text-white">Calculator Preview</h2>
      <div className="bg-white p-2 mb-4 rounded dark:bg-gray-800 dark:text-white">
        {components.length > 0 ? components[components.length - 1].label : "0"}
      </div>
      <div className="grid grid-cols-4 gap-2">
        {components.map((component, index) => (
          <button
            key={index}
            onClick={() => {
              if (component.type === "clear") {
                removeComponent(index)
              } else {
                calculate(component.label)
              }
            }}
            className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition-colors"
          >
            {component.label}
          </button>
        ))}
      </div>
    </div>
  )
}

export default CalculatorPreview

