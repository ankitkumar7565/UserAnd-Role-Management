import { useDrag } from "react-dnd"
import { useCalculatorStore } from "../store/calculatorStore"
import type React from "react" // Import React

const ComponentPalette: React.FC = () => {
  const { addComponent } = useCalculatorStore()

  const components = [
    { type: "number", label: "1" },
     { type: "number", label: "2" },
      { type: "number", label: "3" },
       { type: "number", label: "4" },
        { type: "number", label: "5" },
         { type: "number", label: "6" },
          { type: "number", label: "7" },
           { type: "number", label: "8" },
           { type: "number", label: "9" },
          

    { type: "operator", label: "+" },
    { type: "operator", label: "-" },
    { type: "operator", label: "*" },
    { type: "operator", label: "/" },
    { type: "equals", label: "=" },
    { type: "clear", label: "C" },
  ]

  return (
    <div className="bg-gray-100 p-4 rounded-lg shadow-md dark:bg-gray-800">
      <h2 className="text-xl font-semibold mb-4 dark:text-white">Component Palette</h2>
      <div className="grid grid-cols-3 gap-2">
        {components.map((component, index) => (
          <DraggableComponent key={index} {...component} />
        ))}
      </div>
    </div>
  )
}

const DraggableComponent: React.FC<{ type: string; label: string }> = ({ type, label }) => {
  const [, drag] = useDrag(() => ({
    type: "component",
    item: { type, label },
  }))

  return (
    <div
      ref={drag}
      className="bg-white p-2 rounded cursor-move text-center shadow hover:shadow-md transition-shadow dark:bg-gray-700 dark:text-white"
    >
      {label}
    </div>
  )
}

export default ComponentPalette

