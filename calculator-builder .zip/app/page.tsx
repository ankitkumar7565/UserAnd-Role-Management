"use client"

import { DndProvider } from "react-dnd"
import { HTML5Backend } from "react-dnd-html5-backend"
import CalculatorBuilder from "../components/CalculatorBuilder"

export default function Home() {
  return (
    <DndProvider backend={HTML5Backend}>
      <main className="flex min-h-screen flex-col items-center justify-center p-24">
        <h1 className="text-4xl font-bold mb-8">Calculator Builder</h1>
        <CalculatorBuilder />
      </main>
    </DndProvider>
  )
}

