import { create } from "zustand"
import { persist } from "zustand/middleware"

interface Component {
  type: string
  label: string
}

interface CalculatorState {
  components: Component[]
  addComponent: (component: Component) => void
  removeComponent: (index: number) => void
  clearComponents: () => void
  calculate: (value: string) => void
}

export const useCalculatorStore = create<CalculatorState>()(
  persist(
    (set, get) => ({
      components: [],
      addComponent: (component) => set((state) => ({ components: [...state.components, component] })),
      removeComponent: (index) => set((state) => ({ components: state.components.filter((_, i) => i !== index) })),
      clearComponents: () => set({ components: [] }),
      calculate: (value) => {
        const { components } = get()
        const lastComponent = components[components.length - 1]

        if (value === "=") {
          try {
            const result = eval(components.map((c) => c.label).join(""))
            set({ components: [{ type: "number", label: result.toString() }] })
          } catch (error) {
            set({ components: [{ type: "number", label: "Error" }] })
          }
        } else if (lastComponent && lastComponent.type === "number" && value !== "C") {
          set({
            components: [...components.slice(0, -1), { type: "number", label: lastComponent.label + value }],
          })
        } else {
          set({ components: [...components, { type: "number", label: value }] })
        }
      },
    }),
    {
      name: "calculator-storage",
    },
  ),
)

